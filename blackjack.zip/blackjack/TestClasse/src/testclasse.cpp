//
//  TestClasse.cpp
//
//  Created by Ingenuity i/o on 2024/11/04.
//  Copyright © 2023 Ingenuity i/o. All rights reserved.
//

#include "testclasse.h"


TestClasse::TestClasse()
{
}

TestClasse::~TestClasse(){
}
