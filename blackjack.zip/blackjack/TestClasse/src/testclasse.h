//
//  TestClasse.h
//  Created by Ingenuity i/o on 2024/11/04
//
//  no description
//  Copyright © 2023 Ingenuity i/o. All rights reserved.
//
#ifndef TESTCLASSE_h
#define TESTCLASSE_h

#ifdef INGESCAPE_FROM_PRI
#include "ingescape.h"
#else
#include <ingescape/ingescape.h>
#endif // INGESCAPE_FROM_PRI

#include <string>

class TestClasse {
public:
    TestClasse();
    ~TestClasse();


private:

};

#endif /* TESTCLASSE_h */
